(function($){
  $(function(){
    $('.burning').burn();
  });
})(jQuery);