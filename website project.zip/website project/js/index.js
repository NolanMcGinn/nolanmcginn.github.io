"use strict"
$(document).ready(function() {
  $('.burning').burn();
});


alert("proceed if your not scared of sharks and body's of water");
document.write(html);

  